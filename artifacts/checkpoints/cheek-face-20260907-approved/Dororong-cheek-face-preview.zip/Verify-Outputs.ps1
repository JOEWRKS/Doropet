param([string]$Repository = 'D:/JOEWRKS/.worktrees/DororongDesktopPet-m1-expression-animation')
$ErrorActionPreference = 'Stop'
$study = Join-Path $Repository 'artifacts/repro/cheek-face-20260907-attempt-1'
$final = Join-Path $study 'candidate-reviewed'
$source = @(Get-Content -LiteralPath (Join-Path $study 'source-before.json') -Raw | ConvertFrom-Json)
$prior = @(Get-Content -LiteralPath (Join-Path $study 'prior-before.json') -Raw | ConvertFrom-Json)
foreach ($entry in $source) {
    if ((Get-FileHash -LiteralPath (Join-Path $Repository $entry.Path)).Hash -ne $entry.SHA256) { throw "Source changed: $($entry.Path)" }
}
foreach ($entry in $prior) {
    if ((Get-FileHash -LiteralPath $entry.Path).Hash -ne $entry.SHA256) { throw "Prior evidence changed: $($entry.Path)" }
}
$files = @(Get-ChildItem -LiteralPath $final -File)
$replayed = 0
foreach ($file in $files | Where-Object Name -ne 'annotation.json') {
    if ((Get-FileHash -LiteralPath $file.FullName).Hash -ne (Get-FileHash -LiteralPath (Join-Path $study "candidate-v5/$($file.Name)")).Hash) { throw "Re-export mismatch: $($file.Name)" }
    $replayed++
}
Add-Type -TypeDefinition @'
using System; using System.IO; using System.Linq; using System.Text; using System.Collections.Generic;
public static class CheekExportAudit {
 public static void Nearest(byte[] a,int w,int h,byte[] b,int bw,int bh) {
  if(bw!=w*4||bh!=h*4)throw new Exception("Nearest dimensions");
  for(int y=0;y<bh;y++)for(int x=0;x<bw;x++)for(int c=0;c<4;c++)
   if(a[((y/4)*w+x/4)*4+c]!=b[(y*bw+x)*4+c])throw new Exception("Nearest pixel mismatch");
 }
 static uint U(byte[] b,int i){return ((uint)b[i]<<24)|((uint)b[i+1]<<16)|((uint)b[i+2]<<8)|b[i+3];}
 static int S(byte[] b,int i){return b[i]*256+b[i+1];}
 static List<Tuple<string,byte[]>> Chunks(string p){
  var b=File.ReadAllBytes(p);if(!b.Take(8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10}))throw new Exception("PNG signature");
  var result=new List<Tuple<string,byte[]>>();int at=8;
  while(at<b.Length){int n=checked((int)U(b,at));if(n<0||at+12+n>b.Length)throw new Exception("Chunk bounds");
   uint crc=0xffffffff;for(int i=at+4;i<at+8+n;i++){crc^=b[i];for(int j=0;j<8;j++)crc=(crc&1)!=0?(crc>>1)^0xedb88320:crc>>1;}
   if((crc^0xffffffff)!=U(b,at+8+n))throw new Exception("CRC mismatch");
   result.Add(Tuple.Create(Encoding.ASCII.GetString(b,at+4,4),b.Skip(at+8).Take(n).ToArray()));at+=12+n;
  }
  if(result.Last().Item1!="IEND")throw new Exception("Missing IEND");return result;
 }
 public static string Apng(string path,string directory){
  var chunks=Chunks(path);var act=chunks.Single(c=>c.Item1=="acTL").Item2;
  if(U(act,0)!=41||U(act,4)!=0)throw new Exception("Frame count/loop");
  var header=chunks.Single(c=>c.Item1=="IHDR").Item2;
  if(U(header,0)!=96||U(header,4)!=96||header[8]!=8||header[9]!=6)throw new Exception("APNG format");
  var frames=new List<List<byte>>();int count=0,ms=0;uint seq=0;
  foreach(var c in chunks){var d=c.Item2;
   if(c.Item1=="fcTL"){
    if(U(d,0)!=seq++||U(d,4)!=96||U(d,8)!=96||U(d,12)!=0||U(d,16)!=0||d[24]!=0||d[25]!=0)throw new Exception("Frame control mismatch");
    int delay=count==40?300:20;if(S(d,20)!=delay||S(d,22)!=1000)throw new Exception("Frame delay");
    ms+=delay;count++;frames.Add(new List<byte>());
   } else if(c.Item1=="IDAT") {if(count!=1)throw new Exception("IDAT order");frames.Last().AddRange(d);}
   else if(c.Item1=="fdAT"){if(count<2||U(d,0)!=seq++)throw new Exception("fdAT sequence");frames.Last().AddRange(d.Skip(4));}
  }
  if(count!=41||ms!=1100)throw new Exception("Animation duration/count");
  for(int i=0;i<count;i++){
   var source=Chunks(Path.Combine(directory,"motion-"+(i*20).ToString("D3")+".png"));
   if(!header.SequenceEqual(source.Single(c=>c.Item1=="IHDR").Item2))throw new Exception("Frame header differs");
   if(!frames[i].SequenceEqual(source.Where(c=>c.Item1=="IDAT").SelectMany(c=>c.Item2)))throw new Exception("Animation image differs from PNG "+i);
  }
  return "41/41 compressed frame payloads exact; all CRC/sequence/dimensions valid; 1100ms loop";
 }
}
'@
Add-Type -AssemblyName PresentationCore
function Read-Png([string]$Path) {
    $decoder = [Windows.Media.Imaging.BitmapDecoder]::Create([Uri]$Path,[Windows.Media.Imaging.BitmapCreateOptions]::PreservePixelFormat,[Windows.Media.Imaging.BitmapCacheOption]::OnLoad)
    $bitmap = [Windows.Media.Imaging.FormatConvertedBitmap]::new($decoder.Frames[0],[Windows.Media.PixelFormats]::Bgra32,$null,0)
    $pixels = [byte[]]::new($bitmap.PixelWidth*$bitmap.PixelHeight*4)
    $bitmap.CopyPixels($pixels,$bitmap.PixelWidth*4,0)
    return @{ Width=$bitmap.PixelWidth; Height=$bitmap.PixelHeight; Pixels=$pixels }
}
$nearestPairs = 0
foreach ($file in $files | Where-Object Name -like '*-native.png') {
    $a = Read-Png $file.FullName
    $b = Read-Png (Join-Path $final $file.Name.Replace('-native.png','-nearest4x.png'))
    [CheekExportAudit]::Nearest($a.Pixels,$a.Width,$a.Height,$b.Pixels,$b.Width,$b.Height)
    $nearestPairs++
}
$html = Get-Content -LiteralPath (Join-Path $final 'playback.html') -Raw
$match = [regex]::Match($html,'const records=(\[.*?\]),imgs=',[Text.RegularExpressions.RegexOptions]::Singleline)
if (!$match.Success) { throw 'Playback records missing' }
$records = @($match.Groups[1].Value | ConvertFrom-Json)
if ($records.Count -ne 41) { throw 'Playback frame count' }
foreach ($record in $records) {
    $bytes = [Convert]::FromBase64String($record.uri.Substring('data:image/png;base64,'.Length))
    if ([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)) -ne (Get-FileHash -LiteralPath (Join-Path $final $record.file)).Hash) { throw "Embedded image mismatch: $($record.file)" }
}
$apng = [CheekExportAudit]::Apng((Join-Path $final 'cheek-face-animation.png'),$final)
$checks = Get-Content -LiteralPath (Join-Path $final 'checks.json') -Raw | ConvertFrom-Json
if ($checks.failed -ne 0) { throw 'Proof checks failed' }
Push-Location $Repository
try {
    $head = git rev-parse HEAD
    if ($head -ne '29750fe74967e611e267fa6cd3367a5928902b4c') { throw 'HEAD changed' }
    $branch = git branch --show-current
    if ($branch -ne 'feature/dororong-m1-expression-animation') { throw 'Branch changed' }
    git diff --check
    if ($LASTEXITCODE -ne 0) { throw 'Diff check failed' }
    if (git diff --cached --name-only) { throw 'Index not empty' }
} finally { Pop-Location }
$evidence = [ordered]@{
    status='READY_FOR_ONE_SIDE_USER_PREVIEW_ONLY'; checks=$checks.total; failed=$checks.failed
    unchangedSourceTestToolFiles=$source.Count; unchangedPriorCarryEvidenceFiles=$prior.Count
    exactReExportFiles=$replayed; reExportException='annotation.json now documents existing motion path/collar; no image change'
    exactNearestPairs=$nearestPairs; exactEmbeddedPlaybackPngs=$records.Count; apngAudit=$apng
    currentHead=$head; branch=$branch; productApplication='NOT APPLIED'
    visualStatus='UNVERIFIED'; userAcceptance='UNVERIFIED'; liveInteraction='NOT TESTED'
    productBuildAndLaunch='NOT PERFORMED'; commitPushPr='NOT PERFORMED'
}
$evidence | ConvertTo-Json -Depth 5 | Out-File -LiteralPath (Join-Path $study 'evidence.json') -Encoding utf8
$evidence | ConvertTo-Json -Depth 5

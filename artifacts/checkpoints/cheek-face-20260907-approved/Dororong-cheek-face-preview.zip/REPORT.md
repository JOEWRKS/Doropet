# One-side broader facial cheek proof — 2026-09-07

Status: READY FOR USER PREVIEW ONLY. Visual naturalness and user acceptance remain UNVERIFIED. Product NOT APPLIED; the running app was not replaced.

## Review

Open `candidate-reviewed/playback.html` for native and 4× playback with pause/scrub. `cheek-face-animation.png` is a lossless APNG of the same 41 exported frames. `rest-old-new-nearest4x.png` reads left to right: rest, accepted cheek-only maximum, proposed face-follow maximum.

The cheek interior now propagates into under-eye and mouth-adjacent skin. The selected eye footprint (87 pixels) and mouth footprint (45 pixels) share a rigid translation, without scaling. Maximum movement is one native pixel left and two down. From 0–10 DIP they move down with smoothstep; from 10–20 DIP they move left. This authored path avoids contact with four observed bang-edge pixels. It is not an anatomical reconstruction claim.

Vacated eye/mouth footprints are filled from nearby source colours. Intermediate feature translation uses local bilinear coverage and therefore can soften the features. Source-selected footprints and editable masks are disclosed in annotation.json; they are authored selections, not independently proven semantic segmentation. The original angular cheek tip remains. This proof intentionally preserves the accepted outer envelope rather than widening it across more hair.

Horizontal gain 0.5, outward 20 DIP / inward −10 DIP and 220 ms restoration are retained. Inward rendering uses the accepted algorithm unchanged. The current carry controller is not modified or exercised by this isolated playback.

## Failures retained and corrections

- Baseline actual behavior: 4 failed checks / 8 controls passed. An initial extra-outer-envelope probe was dropped when the implementation chose broader interior propagation while retaining the accepted exterior. That abandoned criterion is not counted as satisfied.
- v1: one eye pixel was overwritten by independently positioned mouth pixels. Shared eye/mouth translation replaces the colliding motions. Intermediate failed experiments remain in their original directories/logs.
- v2: 12 checks passed, but reviewer identified that the inner-skin probe lay in a moved mouth footprint and that transition protection evidence was insufficient. Probe changed to (23,60), outside both feature destinations; declared-region and contour sweeps added.
- v3: 83 accepted contour-ink differences across 81 strength samples. v4 restores the accepted renderer's full geometric 1.5-pixel edge collar.
- Parent inspection found fractional eye motion blending over four bang-boundary pixels. Added regression was RED with 196 differences; v5's vertical-first path yields zero at those probes. No blanket claim that every semantically classified hair pixel has been independently proven invariant.

## Executed verification

Final isolated tool: `dotnet run --project artifacts/repro/cheek-face-20260907-attempt-1/proof-tool/Proof.csproj -c Release -- src/Dororong.App/Assets/body-drag-entry-00-press.png artifacts/repro/cheek-face-20260907-attempt-1/candidate-reviewed` — exit 0; 16/16 checks.

`pwsh -NoProfile -File artifacts/repro/cheek-face-20260907-attempt-1/Verify-Outputs.ps1` — exit 0:

- 185 source/test/tool files and 1283 prior carry evidence files unchanged.
- 68 final files exactly reproduce v5. Only annotation.json differs, documenting the already-rendered path and boundary collar.
- 11 native/4× pairs are exact nearest-neighbor copies.
- HTML embeds all 41 PNG files byte-exactly.
- APNG contains all 41 original PNG compressed image payloads exactly; CRC, sequence, dimensions, frame delays and 1100 ms total loop verified.
- HEAD remains 29750fe74967e611e267fa6cd3367a5928902b4c; index empty; git diff --check exit 0. Existing EOL warnings were not acted on.

Pixel checks establish selected coordinates, masks and sampled quantities only. They do not prove naturalness or runtime interaction quality. Parent inspected static comparisons and intermediate poses; independent reviewer inspected code and static native/4× poses. Neither claimed a live product trial for this proof.

## Handoff

User-preview gate only. No product source/assets/timing/carry changes, product build, app replacement, commit, push or PR. Standalone WPF proof compilation and local preview server are the only execution additions. Historical failed proofs preserved.

Next: user judges the face-follow direction and strength. Product integration requires a subsequent approval.
